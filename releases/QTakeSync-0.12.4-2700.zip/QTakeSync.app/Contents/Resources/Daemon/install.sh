#!/bin/bash -p
# QTakeSync daemon installer / uninstaller. Runs as root (the app starts it
# through an AppleScript administrator prompt, as
# `/usr/bin/env -i PATH=... /bin/bash -p install.sh ...`).
#   install.sh install [--no-token] <path to QTakeSync.app>
#   install.sh update <path to new QTakeSync.app> <app cdhash> <daemon cdhash>
#                                      (replaces /Applications/QTakeSync.app; the CDHashes
#                                       are the ones the app verified, 40 lowercase hex each)
#   install.sh update-staged <app in the root-owned updates dir> <app cdhash> <daemon cdhash>
#                                      (ADR-0009 phase 2: run by the one-shot launchd job
#                                       local.qtakesync.updater that the running daemon starts;
#                                       same checks and apply as `update`, see below)
#   install.sh uninstall
# Root trusts the user-writable app bundle as little as possible: the bundle is
# copied once into a root-only staging directory, and everything (signature
# check, CDHash, daemon binary) is taken from that copy. The launchd plist is
# generated here, never copied from the bundle.
# Never touches /Library/Application Support/QTakeAccess/ (prototype secret).
# Daemon layouts (ADR-0010). The staged app carries the daemon either as the
# legacy bare file Contents/Resources/Daemon/QTakeSyncDaemon (installed as
# /Library/PrivilegedHelperTools/local.qtakesync.daemon) or as the bundle
# Contents/Helpers/QTakeSync Service.app (installed as
# /Library/PrivilegedHelperTools/QTakeSync Service.app, executable
# Contents/MacOS/QTakeSyncDaemon). A bundle must carry the QTakeSync code
# signing certificate (DAEMON_CERT_SHA1) with the fixed designated requirement:
# a bundle with any other signature is refused, because such a build switches the
# Full Disk Access entry off (ADR-0010, spike case D). For the bundle layout the
# <daemon cdhash> argument of `update` is the cdhash of that bundle as printed by
# `codesign -dvvv "QTakeSync Service.app"`.
# update-staged (ADR-0009 phase 2): the daemon copied and verified the release into
# /Library/Application Support/QTakeSync/updates/<build>/QTakeSync.app and started
# this script as a one-shot launchd job (RunAtLoad, no KeepAlive). The app path must
# be exactly that shape; every component from CONF_DIR down must be a real directory
# (no symlink), root:wheel, without group/other write and without ACL, and the app
# tree must be root-owned without group/other write. After the same checks and apply
# as `update` (plus: build strictly newer, build equals the directory name) the app is
# installed owned by the console user, and updates/last-result.json
# {build, ok, message, finishedAt} is written atomically (0644), success or failure
# (not when the updates dir itself is untrusted). The job does NOT boot itself out
# (bootout of the job we run in would kill us or wait for our own exit): it ends, and
# the daemon removes the finished job (`launchctl bootout system/local.qtakesync.updater`)
# and the stage dir on its next start. Update public key: the base64 Ed25519 key of
# the verified staged app (Info.plist QTSUpdatePublicKey) is written to config.json
# as "updatePublicKey" on install and update.
# Update key guard (audit decision #18): `update` refuses a bundle whose
# QTSUpdatePublicKey differs from the installed "updatePublicKey" (or is missing while one is
# installed) with exit code 22 (EXIT_KEY_CHANGED), before anything is changed. An
# intentional key change needs the explicit flag: `update --rotate-key <app> <app cdhash>
# <daemon cdhash>` (never accepted by update-staged). No valid installed key (first
# install, pre-0.8 install): nothing to compare, the update goes ahead.
# Setup token (ADR-0009): after a successful `install` a random 256-bit token is
# generated; only its SHA-256 (of the 64 lowercase hex characters, no newline)
# goes to state/setup-token.json (root:wheel 0600). The token itself is printed
# once, as the last stdout line `QTAKESYNC-SETUP-TOKEN <64hex>`, never to stderr
# or a log. Issued only when no secret exists yet and `--no-token` is absent; a
# token failure only warns on stderr (exit 0, no token line). `update` and `uninstall` delete any existing token file.
# Downgrade guard: a daemon older than the installed one is refused with exit
# code 20 (EXIT_DOWNGRADE) before anything is changed. The version of a daemon
# is CFBundleShortVersionString + CFBundleVersion of the app bundle that carries
# it (the daemon is sealed inside that bundle, so the signature check covers
# it). The installed version is the "version"/"build" pair in config.json
# (root-owned, written by this script). An install without that pair (written
# by 0.5.0 or older) counts as older than any version and is replaced. A file
# that has a "version" or "build" key but cannot be parsed is an error (fail closed).
set -euo pipefail
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH

LABEL="local.qtakesync.daemon"
RIGHT="local.qtakesync.admin"
HELPER_DIR="/Library/PrivilegedHelperTools"
BIN_DST="$HELPER_DIR/$LABEL"           # legacy bare daemon file
BUNDLE_NAME="QTakeSync Service.app"
BUNDLE_DST="$HELPER_DIR/$BUNDLE_NAME"
BUNDLE_EXE_REL="Contents/MacOS/QTakeSyncDaemon"
BUNDLE_EXE_DST="$BUNDLE_DST/$BUNDLE_EXE_REL"
APP_BUNDLE_REL="Contents/Helpers/$BUNDLE_NAME"
APP_LEGACY_REL="Contents/Resources/Daemon/QTakeSyncDaemon"
# SHA-1 of the leaf certificate "QTakeSync Code Signing" (ADR-0010). The only
# place it is written down in this script. Replacing the certificate means a new
# value here, one release and one Full Disk Access grant per Mac.
DAEMON_CERT_SHA1="CBBA65FBEC727E2255D32B941695C1CF8A4E5960"
PLIST_DIR="/Library/LaunchDaemons"
PLIST_DST="$PLIST_DIR/$LABEL.plist"
CONF_DIR="/Library/Application Support/QTakeSync"
CONF_FILE="$CONF_DIR/config.json"
STATE_DIR="$CONF_DIR/state"

EXIT_DOWNGRADE=20
EXIT_NOT_NEWER=21
EXIT_KEY_CHANGED=22
ROTATE_KEY=0
UPDATER_LABEL="local.qtakesync.updater"
# ADR-0011: the user's uploader agent (plist written by the app, not by this script).
UPLOADER_LABEL="local.qtakesync.uploader"
UPLOADER_BUNDLE_NAME="QTakeSync Uploader.app"
UPLOADER_MACH_SERVICE="local.qtakesync.daemon.uploader"
UPDATES_DIR="$CONF_DIR/updates"
RESULT_FILE="$UPDATES_DIR/last-result.json"
ROOT_USER="root"
ROOT_GROUP="wheel"
# update-staged state: STAGED_MODE=1 turns on the result file written by cleanup.
STAGED_MODE=0
# UPDATE_RUN=1 inside cmd_update (plain and staged): also write the public result file.
UPDATE_RUN=0
INTERRUPTED=0
PUBLIC_RESULT_FILE="$CONF_DIR/update-result.json"
STAGED_BUILD=""
RESULT_ENABLED=0
RESULT_MSG=""
LAST_MSG=""
OWNER_OVERRIDE=""
STAGED_PUBKEY=""
SETUP_TOKEN_FILE="$STATE_DIR/setup-token.json"
SETUP_TOKEN=""
# Prototype/first-run secret; a token is issued only while it does not exist
# (same path as QTakeSyncDaemonConstants.secretPath). Read-only check here.
SECRET_FILE="/Library/Application Support/QTakeAccess/secret"

die() { LAST_MSG="$*"; echo "install.sh: $*" >&2; exit 1; }

# Rename a directory into $2 without following a symlink and without ever moving it INTO
# an existing directory. The checks "$2 does not exist" before a plain mv are racy (a
# same-user process can create $2 in the gap; /Applications is group-writable): mv -h makes
# a symlink target fail, and the device:inode comparison catches a real directory that
# appeared (mv would then have put $1 inside it, so it is moved back out and 1 returned).
move_dir_to() {
  local src="$1" dst="$2" id
  id="$(stat -f '%d:%i' "$src")" || return 1
  mv -h "$src" "$dst" 2>/dev/null || return 1
  if [ -L "$dst" ] || [ "$(stat -f '%d:%i' "$dst" 2>/dev/null)" != "$id" ]; then
    [ ! -e "$dst/$(basename "$src")" ] || mv -h "$dst/$(basename "$src")" "$src" 2>/dev/null || true
    return 1
  fi
}

[ "$(id -u)" -eq 0 ] || die "must run as root"

# One installer at a time: mkdir is atomic. A lock older than 10 minutes (an
# installer killed without its EXIT trap) is taken over.
LOCK_DIR="$CONF_DIR/.install.lock"
LOCK_HELD=0
acquire_lock() {
  [ -d "$CONF_DIR" ] || install -d -m 0755 -o root -g wheel "$CONF_DIR"
  if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    if [ -d "$LOCK_DIR" ] && [ ! -L "$LOCK_DIR" ] && [ -n "$(find "$LOCK_DIR" -maxdepth 0 -mmin +10 -print)" ]; then
      rmdir "$LOCK_DIR" 2>/dev/null && mkdir "$LOCK_DIR" 2>/dev/null || die "another install.sh is running"
    else
      die "another install.sh is running (lock $LOCK_DIR)"
    fi
  fi
  LOCK_HELD=1
}

STAGE=""
SAPP=""
SBIN=""
SBUNDLE=""
LAYOUT=""
HASH=""
NEW_VER=""
NEW_BUILD=""
NEW_APP_TMP=""
OLD_APP_TMP=""
SNAP=""
TMP_FILES=()
cleanup() {
  local rc=$?
  local f
  [ "$LOCK_HELD" -eq 1 ] && rmdir "$LOCK_DIR" 2>/dev/null || true
  for f in ${TMP_FILES[@]+"${TMP_FILES[@]}"}; do
    [ -n "$f" ] && rm -f "$f" 2>/dev/null || true
  done
  case "$STAGE" in
    "$CONF_DIR"/.stage.*) rm -rf "$STAGE" 2>/dev/null || true ;;
  esac
  case "$SNAP" in
    "$CONF_DIR"/.snap.*) rm -rf "$SNAP" 2>/dev/null || true ;;
  esac
  case "$NEW_APP_TMP" in
    /Applications/.QTakeSync.app.new-*) rm -rf "$NEW_APP_TMP" 2>/dev/null || true ;;
  esac
  # Interrupted (TERM, kill of the shell, any exit) between moving the old app aside
  # and putting the new one in place: never leave /Applications without the app.
  case "$OLD_APP_TMP" in
    /Applications/.QTakeSync.app.old-*)
      if [ -d "$OLD_APP_TMP/QTakeSync.app" ] && [ ! -L "$OLD_APP_TMP/QTakeSync.app" ] \
         && [ ! -e "$APP_DST" ] && [ ! -L "$APP_DST" ]; then
        move_dir_to "$OLD_APP_TMP/QTakeSync.app" "$APP_DST" \
          || echo "install.sh: RESTORE FAILED, old app is in $OLD_APP_TMP" >&2
      fi ;;
  esac
  # An old copy is kept (not deleted) if a restore may be needed.
  if [ -z "${OLD_APP_TMP_KEEP:-}" ]; then
    case "$OLD_APP_TMP" in
      /Applications/.QTakeSync.app.old-*) [ ! -e "$OLD_APP_TMP/QTakeSync.app" ] && rmdir "$OLD_APP_TMP" 2>/dev/null || true ;;
    esac
  fi
  # Last: the result file for the app (update-staged only; no-op until the updates
  # dir has been validated).
  if [ "$STAGED_MODE" -eq 1 ] || [ "$UPDATE_RUN" -eq 1 ]; then
    if [ "$rc" -eq 0 ]; then
      write_result true "${RESULT_MSG:-updated}"
    else
      write_result false "${LAST_MSG:-install.sh failed (exit $rc)}"
    fi
  fi
  return 0
}

# Atomic JSON file: temp file in the same directory, then mv. Skipped (silently)
# when the directory or the target is a symlink, or the target is a directory.
write_json_atomic() { # dir target json
  local dir="$1" dst="$2" tmp
  [ -d "$dir" ] && [ ! -L "$dir" ] || return 0
  [ ! -L "$dst" ] && [ ! -d "$dst" ] || return 0
  tmp="$(mktemp "$dir/.result.XXXXXX")" || return 0
  printf '%s\n' "$3" > "$tmp" || { rm -f "$tmp"; return 0; }
  chown "$ROOT_USER:$ROOT_GROUP" "$tmp" 2>/dev/null || true
  chmod 0644 "$tmp" || { rm -f "$tmp"; return 0; }
  mv -f "$tmp" "$dst" 2>/dev/null || rm -f "$tmp"
  return 0
}

# Writes {build, ok, message, finishedAt}: updates/last-result.json (update-staged,
# once the updates dir is trusted) and, as the very last step, the world-readable
# $CONF_DIR/update-result.json (update-staged and update). The message is reduced to
# printable ASCII, JSON-escaped, cut at 500 characters. Nothing secret goes in.
write_result() { # ok(true|false) message
  local build="" msg now json
  if [ -n "$STAGED_BUILD" ]; then build="$STAGED_BUILD"; elif is_build "$NEW_BUILD"; then build="$NEW_BUILD"; fi
  [ -n "$build" ] || return 0
  msg="$(printf '%s' "$2" | LC_ALL=C tr -cd ' -~' | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' | cut -c1-500)" || msg="see install.log"
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  json="$(printf '{"build":%s,"ok":%s,"message":"%s","finishedAt":"%s"}' "$((10#$build))" "$1" "$msg" "$now")"
  if [ "$RESULT_ENABLED" -eq 1 ]; then write_json_atomic "$UPDATES_DIR" "$RESULT_FILE" "$json"; fi
  if [ "$UPDATE_RUN" -eq 1 ]; then write_json_atomic "$CONF_DIR" "$PUBLIC_RESULT_FILE" "$json"; fi
  return 0
}
trap cleanup EXIT

wait_unloaded() {
  local i
  for i in 1 2 3 4 5 6 7 8 9 10; do
    launchctl print "system/$LABEL" >/dev/null 2>&1 || return 0
    sleep 0.5
  done
  return 0
}

# Unmounts leftover merge/probe SMB mounts of the daemon. Only mounts whose
# mount point is /Volumes/.qtakesync-merge.* or /Volumes/.qtakesync-probe.*,
# whose type is smbfs and whose owner is root are touched; nothing else.
unmount_leftovers() {
  local line mp fstype owner n=0
  while IFS= read -r line; do
    mp="$(printf '%s\n' "$line" | sed -nE 's#^.* on (/Volumes/\.qtakesync-(merge|probe)\.[^ ]*) \(([^,)]*).*$#\1#p')"
    [ -n "$mp" ] || continue
    fstype="$(printf '%s\n' "$line" | sed -nE 's#^.* on /Volumes/[^ ]* \(([^,)]*).*$#\1#p')"
    [ "$fstype" = "smbfs" ] || continue
    [ -d "$mp" ] && [ ! -L "$mp" ] || continue
    owner="$(stat -f %Su "$mp" 2>/dev/null)" || continue
    [ "$owner" = "root" ] || continue
    umount -f "$mp" 2>/dev/null || diskutil unmount force "$mp" >/dev/null 2>&1 || true
    # Remove the directory only if it is now an empty, unmounted directory.
    rmdir "$mp" 2>/dev/null || true
    n=$((n + 1))
  done < <(mount)
  [ "$n" -eq 0 ] || echo "Unmounted $n leftover QTakeSync merge/probe mount(s)."
  return 0
}

# Removes com.apple.quarantine from the whole tree $1 (top directory included),
# then refuses if any is left. `ditto --noqtn` does NOT do this (it leaves the
# attribute on the top-level directory and on files that carry it, observed on
# macOS 15.5 after an AirDrop transfer), and a quarantined helper is rejected by
# Gatekeeper at launch (OS_REASON_EXEC). Only the quarantine attribute is
# removed (not com.apple.provenance). -s: symlinks are not followed.
strip_quarantine() {
  local d="$1" left
  xattr -rsd com.apple.quarantine "$d" 2>/dev/null || die "cannot remove the quarantine attribute from $d"
  left="$(xattr -lrs "$d" 2>/dev/null || true)"
  if printf '%s\n' "$left" | grep 'com.apple.quarantine' >/dev/null; then
    die "quarantine attribute still present on $d"
  fi
  return 0
}

# Explicit modes for a tree $1: owner rwX, everyone else rX, never group/other
# write (dirs 0755, files 0644, anything executable 0755). Needed because ditto
# copies the source modes, and a bundle built under umask 077 has 0700 dirs and
# 0600 files: System Settings and tccd run as the user and could not read such a
# service bundle (Full Disk Access toggle did nothing, macOS 15.5 rehearsal).
normalize_modes() {
  chmod -R u=rwX,go=rX "$1" || die "cannot set modes on $1"
}

# Refuses a tree where something is not readable by others (files and dirs) or a
# directory cannot be entered by others.
check_world_readable() {
  [ -z "$(find "$1" ! -perm -o+r -print -quit)" ] || die "$1 contains items not readable by others"
  [ -z "$(find "$1" -type d ! -perm -o+x -print -quit)" ] || die "$1 contains directories others cannot enter"
}

# Lowercase hex of the pinned certificate and the requirement string for it.
daemon_cert_hex() { printf '%s' "$DAEMON_CERT_SHA1" | tr 'A-F' 'a-f'; }
# The expression form for `codesign --verify -R "=<expr>"`; the release script
# signs with the same expression behind `designated =>` (a `designated =>` prefix
# is a syntax error for -R).
daemon_requirement() {
  printf '=identifier "%s" and certificate leaf = H"%s"' "$LABEL" "$(daemon_cert_hex)"
}

# Decides the daemon layout inside the app copy $1 (the staged copy) and sets
# LAYOUT ("bundle" or "legacy"), SBUNDLE (bundle layout) and SBIN (the daemon
# executable: inside the bundle, or the bare file). Both present: refused.
detect_layout() {
  local sapp="$1" b l has_b=0 has_l=0
  b="$sapp/$APP_BUNDLE_REL"; l="$sapp/$APP_LEGACY_REL"
  LAYOUT=""; SBUNDLE=""; SBIN=""
  if [ -e "$b" ] || [ -L "$b" ] || [ -L "$sapp/Contents/Helpers" ]; then has_b=1; fi
  if [ -e "$l" ] || [ -L "$l" ]; then has_l=1; fi
  if [ "$has_b" -eq 1 ] && [ "$has_l" -eq 1 ]; then die "app carries the daemon in both layouts (bundle and bare file)"; fi
  if [ "$has_b" -eq 1 ]; then
    [ -d "$b" ] && [ ! -L "$b" ] && [ ! -L "$sapp/Contents/Helpers" ] || die "service bundle is not a plain directory in the app bundle"
    LAYOUT="bundle"; SBUNDLE="$b"; SBIN="$b/$BUNDLE_EXE_REL"
    [ -f "$SBIN" ] && [ ! -L "$SBIN" ] || die "service bundle executable missing or a symlink"
  elif [ "$has_l" -eq 1 ]; then
    LAYOUT="legacy"; SBIN="$l"
    [ -f "$SBIN" ] && [ ! -L "$SBIN" ] || die "daemon binary missing or a symlink in the app bundle"
  else
    die "no daemon found in the app bundle (neither $APP_BUNDLE_REL nor $APP_LEGACY_REL)"
  fi
}

# Verifies a service bundle at $1 (staged or installed copy): file types, plist,
# signature with the pinned certificate and requirement, hardened runtime. Dies
# on any problem; the bundle is trusted only if it comes out clean.
verify_service_bundle() {
  local b="${1%/}" info bid exe req
  [ -d "$b" ] && [ ! -L "$b" ] || die "service bundle is not a directory"
  [ -z "$(find "$b" -acl -print -quit)" ] || die "service bundle carries ACLs"
  [ -z "$(find "$b" -perm -o+w -print -quit)" ] || die "service bundle contains world-writable items"
  [ -z "$(find "$b" \( -perm -4000 -o -perm -2000 \) -print -quit)" ] || die "service bundle contains setuid/setgid files"
  [ -z "$(find "$b" ! -type f ! -type d -print -quit)" ] \
    || die "service bundle contains entries that are not regular files or directories (symlinks are refused too)"
  bid="$(plutil -extract CFBundleIdentifier raw -o - "$b/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read the service bundle identifier"
  [ "$bid" = "$LABEL" ] || die "unexpected service bundle identifier: $bid"
  exe="$(plutil -extract CFBundleExecutable raw -o - "$b/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read the service bundle executable name"
  [ "$exe" = "QTakeSyncDaemon" ] || die "unexpected service bundle executable: $exe"
  [ -f "$b/$BUNDLE_EXE_REL" ] && [ ! -L "$b/$BUNDLE_EXE_REL" ] || die "service bundle executable missing"
  req="$(daemon_requirement)"
  codesign --verify --strict -R "$req" "$b" 2>/dev/null \
    || die "service bundle is not signed by the QTakeSync code signing certificate (a different signature would switch Full Disk Access off)"
  info="$(codesign -dvvv "$b" 2>&1)" || die "cannot read the service bundle signature"
  printf '%s\n' "$info" | grep -E '^CodeDirectory .*flags=0x[0-9a-fA-F]+\([^)]*runtime' >/dev/null \
    || die "service bundle has no hardened runtime"
  return 0
}

# ADR-0011: verifies the uploader bundle inside the staged app, if there is one (an older
# layout without it is fine). Same rules as the service bundle: plain files, pinned
# certificate and identifier, hardened runtime. A bundle signed otherwise is refused.
verify_uploader_bundle() {
  local sapp="$1" b info bid req
  b="$sapp/Contents/Helpers/$UPLOADER_BUNDLE_NAME"
  if [ ! -e "$b" ] && [ ! -L "$b" ]; then return 0; fi
  [ -d "$b" ] && [ ! -L "$b" ] && [ ! -L "$sapp/Contents/Helpers" ] || die "uploader bundle is not a plain directory in the app bundle"
  [ -z "$(find "$b" -acl -print -quit)" ] || die "uploader bundle carries ACLs"
  [ -z "$(find "$b" -perm -o+w -print -quit)" ] || die "uploader bundle contains world-writable items"
  [ -z "$(find "$b" \( -perm -4000 -o -perm -2000 \) -print -quit)" ] || die "uploader bundle contains setuid/setgid files"
  [ -z "$(find "$b" ! -type f ! -type d -print -quit)" ] \
    || die "uploader bundle contains entries that are not regular files or directories (symlinks are refused too)"
  bid="$(plutil -extract CFBundleIdentifier raw -o - "$b/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read the uploader bundle identifier"
  [ "$bid" = "$UPLOADER_LABEL" ] || die "unexpected uploader bundle identifier: $bid"
  req="$(printf '=identifier "%s" and certificate leaf = H"%s"' "$UPLOADER_LABEL" "$(daemon_cert_hex)")"
  codesign --verify --strict -R "$req" "$b" 2>/dev/null \
    || die "uploader bundle is not signed by the QTakeSync code signing certificate"
  info="$(codesign -dvvv "$b" 2>&1)" || die "cannot read the uploader bundle signature"
  printf '%s\n' "$info" | grep -E '^CodeDirectory .*flags=0x[0-9a-fA-F]+\([^)]*runtime' >/dev/null \
    || die "uploader bundle has no hardened runtime"
  return 0
}

# Validates the app bundle at $1 and copies it into a root-only staging
# directory. Sets globals: SAPP (staged app), LAYOUT, SBUNDLE, SBIN (staged
# daemon executable), HASH (app CDHash). Everything afterwards uses the staged copy, never the original.
stage_and_verify() {
  local app="${1%/}"
  case "$app" in /*) ;; *) die "app path must be absolute" ;; esac
  case "$app" in *.app) ;; *) die "not an .app bundle: $app" ;; esac
  case "$app" in /Users/Shared/*|/Volumes/*) die "refusing to install from a shared or external location: $app" ;; esac
  [ -d "$app" ] && [ ! -L "$app" ] || die "not a directory: $app"

  # Root-only staging copy; everything below uses it, not the original.
  [ -d "$CONF_DIR" ] || install -d -m 0755 -o root -g wheel "$CONF_DIR"
  STAGE="$(mktemp -d "$CONF_DIR/.stage.XXXXXX")"
  chmod 0700 "$STAGE"
  # --noacl: an ACL on the user-writable original must not survive into root's
  # copy (an ACL could later let the user swap a root-run file).
  ditto --noqtn --noacl "$app" "$STAGE/QTakeSync.app"
  SAPP="$STAGE/QTakeSync.app"
  [ -d "$SAPP" ] && [ ! -L "$SAPP" ] || die "staged app is not a plain directory"
  strip_quarantine "$SAPP"
  find "$SAPP" ! -type l -exec chmod -N {} +
  [ -z "$(find "$SAPP" -acl -print -quit)" ] || die "staged app carries ACLs"
  # Every check below runs on the staged copy only.
  [ -z "$(find "$SAPP" -perm -o+w -print -quit)" ] || die "staged app contains world-writable items"
  [ -z "$(find "$SAPP" \( -perm -4000 -o -perm -2000 \) -print -quit)" ] || die "app bundle contains setuid/setgid files"
  [ -z "$(find "$SAPP" ! -type f ! -type d ! -type l -print -quit)" ] \
    || die "app bundle contains entries that are not regular files, directories or symlinks"
  # A symlink may not point outside the bundle: no absolute target, no ".." part.
  local lnk tgt
  while IFS= read -r -d '' lnk; do
    tgt="$(readlink "$lnk")" || die "cannot read a symlink in the app bundle"
    case "$tgt" in
      /*|..|../*|*/..|*/../*) die "app bundle contains a symlink that leaves the bundle: ${lnk#"$SAPP"/} -> $tgt" ;;
    esac
  done < <(find "$SAPP" -type l -print0)
  detect_layout "$SAPP"

  local bid
  bid="$(plutil -extract CFBundleIdentifier raw -o - "$SAPP/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read CFBundleIdentifier"
  [ "$bid" = "local.qtakesync" ] || die "unexpected bundle identifier: $bid"

  codesign --verify --strict "$SAPP" || die "app signature is invalid"
  if [ "$LAYOUT" = "bundle" ]; then
    verify_service_bundle "$SBUNDLE"
  else
    codesign --verify --strict "$SBIN" || die "daemon signature is invalid"
  fi
  verify_uploader_bundle "$SAPP"

  local info hashes
  info="$(codesign -dvvv "$SAPP" 2>&1)" || die "cannot read app signature"
  printf '%s\n' "$info" | grep -E '^CodeDirectory .*flags=0x[0-9a-fA-F]+\([^)]*runtime' >/dev/null \
    || die "app has no hardened runtime. Debug build? Use a Release build"
  hashes="$(printf '%s\n' "$info" | sed -n 's/^CDHash=\([0-9a-fA-F]*\)$/\1/p' | tr 'A-F' 'a-f')"
  [ -n "$hashes" ] || die "no CDHash found for the app"
  [ "$(printf '%s\n' "$hashes" | wc -l | tr -d ' ')" -eq 1 ] || die "app has several CDHash lines (not arm64-only?)"
  HASH="$hashes"
  case "$HASH" in *[!0-9a-f]*) die "malformed CDHash" ;; esac

  # Version of the staged (verified) bundle; it is the daemon's version too.
  NEW_VER="$(plutil -extract CFBundleShortVersionString raw -o - "$SAPP/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read CFBundleShortVersionString"
  NEW_BUILD="$(plutil -extract CFBundleVersion raw -o - "$SAPP/Contents/Info.plist" 2>/dev/null)" \
    || die "cannot read CFBundleVersion"
  is_version "$NEW_VER" || die "malformed CFBundleShortVersionString: $NEW_VER"
  is_build "$NEW_BUILD" || die "malformed CFBundleVersion: $NEW_BUILD"

  # Update public key of the verified bundle (its Info.plist is sealed by the
  # signature checked above). Empty or absent: omitted from config.json (the daemon
  # then cannot update itself, the AppleScript path still works). Present but not a
  # base64 Ed25519 key (44 chars, 32 bytes): refused.
  STAGED_PUBKEY="$(plutil -extract QTSUpdatePublicKey raw -o - "$SAPP/Contents/Info.plist" 2>/dev/null)" || STAGED_PUBKEY=""
  if [ -z "$STAGED_PUBKEY" ]; then
    echo "install.sh: warning: the app has no QTSUpdatePublicKey; config.json gets no updatePublicKey (the service cannot install updates itself)" >&2
  else
    is_pubkey "$STAGED_PUBKEY" || die "QTSUpdatePublicKey in the app is not a base64 Ed25519 public key"
  fi
  # Bridge rule: the service bundle carries the app's version and build. (0.8
  # project.yml must set the bundle's CFBundleShortVersionString/CFBundleVersion
  # to MARKETING_VERSION/CURRENT_PROJECT_VERSION, or this rule is changed first.)
  if [ "$LAYOUT" = "bundle" ]; then
    local bver bbuild
    bver="$(plutil -extract CFBundleShortVersionString raw -o - "$SBUNDLE/Contents/Info.plist" 2>/dev/null)" \
      || die "cannot read the service bundle version"
    bbuild="$(plutil -extract CFBundleVersion raw -o - "$SBUNDLE/Contents/Info.plist" 2>/dev/null)" \
      || die "cannot read the service bundle build"
    [ "$bver" = "$NEW_VER" ] && [ "$bbuild" = "$NEW_BUILD" ] \
      || die "service bundle version ($bver, build $bbuild) differs from the app ($NEW_VER, build $NEW_BUILD)"
  fi
}

# Dotted numeric version, e.g. 0.6.0 (1 to 4 groups of 1 to 6 digits).
# A value with a newline or CR is rejected first (grep would test line by line).
has_eol() { case "$1" in *$'\n'*|*$'\r'*) return 0 ;; esac; return 1; }
is_version() { ! has_eol "$1" && [[ $1 =~ ^[0-9]{1,6}(\.[0-9]{1,6}){0,3}$ ]]; }
is_build() { ! has_eol "$1" && [[ $1 =~ ^[0-9]{1,9}$ ]]; }
# Base64 of exactly 32 raw bytes (44 characters, one "=" pad), as UpdateVerifier.publicKey reads it.
is_pubkey() {
  ! has_eol "$1" && [[ $1 =~ ^[A-Za-z0-9+/]{43}=$ ]] \
    && [ "$(printf '%s' "$1" | base64 -D 2>/dev/null | wc -c | tr -d ' ')" -eq 32 ]
}

# The exact config.json line apply_daemon writes (and the parser must read).
# The app cdhash stays the pin. daemonLayout / daemonCertSHA1 (bundle only) are
# informational for tools; updatePublicKey (base64 raw Ed25519, from the verified
# app) is what the daemon verifies release records with. Unknown keys are ignored
# by the daemon (JSONDecoder).
config_line() { # hash stamp version build layout [update public key]
  local extra=""
  if [ "$5" = "bundle" ]; then extra=', "daemonCertSHA1": "'"$(daemon_cert_hex)"'"'; fi
  if [ -n "${6:-}" ]; then
    is_pubkey "$6" || die "refusing to write a malformed update public key"
    extra="$extra"', "updatePublicKey": "'"$6"'"'
  fi
  printf '{"appCDHashes": ["%s"], "installedAt": "%s", "version": "%s", "build": %s, "daemonLayout": "%s"%s}\n' \
    "$1" "$2" "$3" "$4" "$5" "$extra"
}

# Reads "version" and "build" from config file $1 into OLD_VER / OLD_BUILD.
# Returns 1 when the file has neither key (an install by 0.5.0 or older).
# Dies when a key is present but the pair is not readable (fail closed).
OLD_VER=""
OLD_BUILD=""
read_installed_version() {
  local f="$1"
  OLD_VER=""; OLD_BUILD=""
  if ! grep -q '"version"\|"build"' "$f"; then return 1; fi
  OLD_VER="$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$f" | head -n 1)" || true
  OLD_BUILD="$(sed -n 's/.*"build"[[:space:]]*:[[:space:]]*\([0-9]*\).*/\1/p' "$f" | head -n 1)" || true
  is_version "$OLD_VER" && is_build "$OLD_BUILD" \
    || die "installed version in $f is unreadable (version '$OLD_VER', build '$OLD_BUILD'). Uninstall the service first"
  return 0
}

# Prints -1, 0 or 1: dotted version $1 compared with $2 (missing groups = 0).
version_cmp() {
  local a b x y i
  IFS=. read -r -a a <<< "$1"
  IFS=. read -r -a b <<< "$2"
  for i in 0 1 2 3; do
    x=$((10#${a[$i]:-0})); y=$((10#${b[$i]:-0}))
    if [ "$x" -lt "$y" ]; then echo -1; return 0; fi
    if [ "$x" -gt "$y" ]; then echo 1; return 0; fi
  done
  echo 0
}

# Refuses (exit 20, nothing changed) when the staged daemon is older than the
# installed one. Same version and build: allowed (repair). Nothing installed,
# or an install without version fields (0.5.0): allowed.
check_downgrade() {
  { [ -f "$BIN_DST" ] || [ -d "$BUNDLE_DST" ]; } && [ -f "$CONF_FILE" ] && [ ! -L "$CONF_FILE" ] || return 0
  local old_ver old_build c
  read_installed_version "$CONF_FILE" || return 0
  old_ver="$OLD_VER"; old_build="$OLD_BUILD"
  c="$(version_cmp "$NEW_VER" "$old_ver")"
  if [ "$c" -eq 0 ]; then
    if [ "$((10#$NEW_BUILD))" -lt "$((10#$old_build))" ]; then c=-1; fi
  fi
  if [ "$c" -lt 0 ]; then
    LAST_MSG="downgrade refused: installed daemon is $old_ver (build $old_build), this app has $NEW_VER (build $NEW_BUILD)"
    echo "install.sh: downgrade refused: installed daemon is $old_ver (build $old_build), this app has $NEW_VER (build $NEW_BUILD). Nothing was changed. Update QTakeSync to the newer version instead." >&2
    exit "$EXIT_DOWNGRADE"
  fi
  return 0
}

check_interrupted() {
  [ "$INTERRUPTED" -eq 0 ] || die "interrupted by a signal before the app was replaced; nothing was changed"
}

# update-staged: the staged app's update public key must equal the installed one
# ("updatePublicKey" in config.json). A different, missing or unreadable key is
# refused: rotation is only possible through `install`/`update` (admin password).
require_same_pubkey() {
  local old=""
  if [ -f "$CONF_FILE" ] && [ ! -L "$CONF_FILE" ]; then
    old="$(sed -n 's/.*"updatePublicKey"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONF_FILE" | head -n 1)" || old=""
  fi
  is_pubkey "$old" || die "update-staged: no valid installed update public key in config.json; reinstall with the administrator password"
  [ -n "$STAGED_PUBKEY" ] && [ "$STAGED_PUBKEY" = "$old" ] \
    || die "update-staged: the new app's update public key differs from the installed one (or is missing); key rotation needs the administrator password"
  return 0
}

# update (plain, run with the administrator password): the new app's update public key must
# equal the installed one. Different or missing while an installed key exists: exit 22,
# nothing changed, unless --rotate-key was given. No valid installed key: allowed.
check_pubkey_change() {
  local old=""
  if [ -f "$CONF_FILE" ] && [ ! -L "$CONF_FILE" ]; then
    old="$(sed -n 's/.*"updatePublicKey"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$CONF_FILE" | head -n 1)" || old=""
  fi
  is_pubkey "$old" || return 0
  [ "$STAGED_PUBKEY" != "$old" ] || return 0
  if [ "$ROTATE_KEY" -eq 1 ]; then
    if ! is_pubkey "$STAGED_PUBKEY"; then
      LAST_MSG="--rotate-key needs a valid QTSUpdatePublicKey in the new app; refused"
      echo "install.sh: $LAST_MSG. Nothing was changed." >&2
      exit "$EXIT_KEY_CHANGED"
    fi
    # stderr goes to install.log; the system log keeps a second, independent record.
    echo "install.sh: warning: update public key ROTATED (--rotate-key): installed $old -> new $STAGED_PUBKEY" >&2
    /usr/bin/logger -t qtakesync-install "update public key rotated via --rotate-key: $old -> $STAGED_PUBKEY" 2>/dev/null || true
    return 0
  fi
  LAST_MSG="update public key changed: the new app's QTSUpdatePublicKey differs from the installed one (or is missing); refused"
  echo "install.sh: $LAST_MSG. Nothing was changed. For an intentional key change run: install.sh update --rotate-key <app> <app cdhash> <daemon cdhash>" >&2
  exit "$EXIT_KEY_CHANGED"
}

# update-staged: the staged build must be strictly newer than the installed one
# (check_downgrade already ran: older is exit 20; equal is refused here, exit 21).
# Nothing installed, or an install without version fields: allowed.
require_strictly_newer() {
  { [ -f "$BIN_DST" ] || [ -d "$BUNDLE_DST" ]; } && [ -f "$CONF_FILE" ] && [ ! -L "$CONF_FILE" ] || return 0
  read_installed_version "$CONF_FILE" || return 0
  local c
  c="$(version_cmp "$NEW_VER" "$OLD_VER")"
  if [ "$c" -eq 0 ]; then
    if [ "$((10#$NEW_BUILD))" -gt "$((10#$OLD_BUILD))" ]; then c=1; else c=-1; fi
  fi
  if [ "$c" -lt 1 ]; then
    LAST_MSG="not newer: installed $OLD_VER (build $OLD_BUILD), staged $NEW_VER (build $NEW_BUILD)"
    echo "install.sh: $LAST_MSG. Nothing was changed." >&2
    exit "$EXIT_NOT_NEWER"
  fi
  return 0
}

# True only for two equal, well-formed cdhashes: "none"/"unknown" never match.
same_cdhash() { is_hash40 "$1" && is_hash40 "$2" && [ "$1" = "$2" ]; }

is_hash40() { [ "${#1}" -eq 40 ] && case "$1" in *[!0-9a-f]*) return 1 ;; esac; }

# CDHash of a single code object (daemon binary), or "none" when absent.
cdhash_of() {
  local f="$1" out
  if [ -L "$f" ] || { [ ! -f "$f" ] && [ ! -d "$f" ]; }; then echo none; return 0; fi
  out="$(codesign -dvvv "$f" 2>&1 | sed -n 's/^CDHash=\([0-9a-fA-F]*\)$/\1/p' | tr 'A-F' 'a-f' | head -n 1)" || true
  echo "${out:-unknown}"
}

# Installs daemon binary, plist, config pin, right and bootstraps, all from the
# staged copy (SBIN, HASH).
apply_daemon() {
  local sbin="$SBIN" hash="$HASH"
  # Stop a running copy before replacing files (ignore failure: not loaded yet).
  launchctl bootout "system/$LABEL" 2>/dev/null || true
  wait_unloaded
  unmount_leftovers

  [ -d "$HELPER_DIR" ] || install -d -m 0755 -o root -g wheel "$HELPER_DIR"
  sweep_stale_helper_dirs
  # Installing the legacy file while a bundle exists: remove the bundle, so the
  # plist and the files on disk never disagree.
  if [ "$LAYOUT" != "bundle" ] && [ -d "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ]; then
    rm -rf "$BUNDLE_DST"   # exact constant path under /Library/PrivilegedHelperTools
  fi
  local program
  if [ "$LAYOUT" = "bundle" ]; then
    install_service_bundle
    program="$BUNDLE_EXE_DST"
  else
    install -m 0755 -o root -g wheel "$sbin" "$BIN_DST"
    program="$BIN_DST"
  fi
  write_launchd_plist "$program"
  apply_rest "$hash"
}

# Installs the staged service bundle (SBUNDLE) into BUNDLE_DST via a staging dir
# inside HELPER_DIR (same volume, so the final mv is a rename). The requirement
# is checked again on the installed copy. An existing bundle is moved aside
# first; apply_cleanup puts it back if the install does not finish.
APPLY_NEW=""
APPLY_ASIDE=""
APPLY_OK=0

# Leftovers of an interrupted bundle install (power loss, kill): staging dirs
# are deleted; a moved-aside old bundle is put back when no bundle is installed,
# otherwise deleted. Only exact `.QTakeSync Service.app.{new,old}-*` directories
# directly in HELPER_DIR (never symlinks) are touched.
sweep_stale_helper_dirs() {
  local d
  for d in "$HELPER_DIR"/.QTakeSync\ Service.app.new-*; do
    [ -d "$d" ] && [ ! -L "$d" ] || continue
    rm -rf "$d" 2>/dev/null || true
  done
  for d in "$HELPER_DIR"/.QTakeSync\ Service.app.old-*; do
    [ -d "$d" ] && [ ! -L "$d" ] || continue
    if [ ! -e "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ] && [ -d "$d/$BUNDLE_NAME" ] && [ ! -L "$d/$BUNDLE_NAME" ]; then
      mv "$d/$BUNDLE_NAME" "$BUNDLE_DST" 2>/dev/null || continue
    fi
    rm -rf "$d" 2>/dev/null || true
  done
}
install_service_bundle() {
  local stg nb
  # The staging dir is made by mktemp (root, 0700); ditto writes into a child so
  # it can never change the owner or mode of the directory itself.
  stg="$(mktemp -d "$HELPER_DIR/.$BUNDLE_NAME.new-XXXXXX")"
  APPLY_NEW="$stg"
  nb="$stg/$BUNDLE_NAME"
  ditto --noqtn --noacl "$SBUNDLE" "$nb"
  [ -d "$nb" ] && [ ! -L "$nb" ] || die "copied service bundle is not a plain directory"
  strip_quarantine "$nb"
  find "$nb" ! -type l -exec chmod -N {} +
  chown -R root:wheel "$nb"
  normalize_modes "$nb"
  verify_service_bundle "$nb"
  check_world_readable "$nb"
  same_cdhash "$(cdhash_of "$nb")" "$(cdhash_of "$SBUNDLE")" || die "service bundle changed while copying (or cdhash unreadable)"
  [ ! -L "$BUNDLE_DST" ] || die "$BUNDLE_DST is a symlink"
  if [ -e "$BUNDLE_DST" ]; then
    [ -d "$BUNDLE_DST" ] || die "$BUNDLE_DST is not a directory"
    local aside
    aside="$(mktemp -d "$HELPER_DIR/.$BUNDLE_NAME.old-XXXXXX")"
    APPLY_ASIDE="$aside"
    mv "$BUNDLE_DST" "$aside/$BUNDLE_NAME" || die "cannot move the installed service bundle aside"
  fi
  [ ! -e "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ] || die "$BUNDLE_DST reappeared while installing"
  mv "$nb" "$BUNDLE_DST" || die "cannot put the service bundle in place"
  rmdir "$stg" 2>/dev/null || true
  APPLY_NEW=""
}

# Writes the launchd plist for the executable $1 (never copied from the app).
write_launchd_plist() {
  local program="$1" ptmp
  ptmp="$(mktemp "$PLIST_DIR/.qtakesync.XXXXXX")"
  TMP_FILES+=("$ptmp")
  cat > "$ptmp" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>$LABEL</string>
	<key>Program</key>
	<string>$program</string>
	<key>RunAtLoad</key>
	<true/>
	<key>KeepAlive</key>
	<true/>
	<key>MachServices</key>
	<dict>
		<key>$LABEL.xpc</key>
		<true/>
		<key>$UPLOADER_MACH_SERVICE</key>
		<true/>
	</dict>
	<key>AssociatedBundleIdentifiers</key>
	<array>
		<string>local.qtakesync</string>
	</array>
</dict>
</plist>
EOF
  plutil -lint "$ptmp" >/dev/null || die "generated plist is invalid"
  chown root:wheel "$ptmp"
  chmod 0644 "$ptmp"
  mv -f "$ptmp" "$PLIST_DST"
}

# Rest of the install: state dir, config pin, authorization right, bootstrap,
# then (bundle layout only) the removal of the legacy bare file.
apply_rest() {
  local hash="$1"
  # Daemon state root (registry, refusals). Contents are never touched here;
  # settings.json and status.json are owned by the app/daemon.
  [ -d "$STATE_DIR" ] || install -d -m 0700 -o root -g wheel "$STATE_DIR"

  local tmp stamp
  stamp="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  tmp="$(mktemp "$CONF_DIR/.config.json.XXXXXX")"
  TMP_FILES+=("$tmp")
  config_line "$hash" "$stamp" "$NEW_VER" "$NEW_BUILD" "$LAYOUT" "$STAGED_PUBKEY" > "$tmp"
  chown root:wheel "$tmp"
  chmod 0644 "$tmp"
  mv -f "$tmp" "$CONF_FILE"

  # Full rule dict (a named rule such as authenticate-admin-nonshared cannot
  # carry our 600 s timeout). Fed on stdin from a temp plist.
  # Rewritten unconditionally on every install and update-staged, so bumping the
  # version marker below (and the timeout) reaches existing installs; the write
  # is idempotent (authorizationdb write replaces the whole definition).
  local rtmp
  rtmp="$(mktemp "$CONF_DIR/.right.XXXXXX")"
  TMP_FILES+=("$rtmp")
  cat > "$rtmp" <<'EOF_RIGHT'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>class</key>
	<string>user</string>
	<key>group</key>
	<string>admin</string>
	<key>shared</key>
	<false/>
	<key>authenticate-user</key>
	<true/>
	<key>allow-root</key>
	<false/>
	<key>timeout</key>
	<integer>600</integer>
	<key>version</key>
	<integer>2</integer>
	<key>comment</key>
	<string>QTakeSync administration</string>
</dict>
</plist>
EOF_RIGHT
  plutil -lint "$rtmp" >/dev/null || die "generated authorization rule is invalid"
  security authorizationdb write "$RIGHT" < "$rtmp" >/dev/null || die "cannot write authorization right $RIGHT"

  launchctl enable "system/$LABEL" 2>/dev/null || true
  local n ok=0
  for n in 1 2 3; do
    if launchctl bootstrap system "$PLIST_DST"; then ok=1; break; fi
    [ "$n" -lt 3 ] && sleep 1
  done
  [ "$ok" -eq 1 ] || die "launchctl bootstrap failed 3 times. Check System Settings > General > Login Items > Allow in the Background"
  APPLY_OK=1

  local binary="$BIN_DST"
  if [ "$LAYOUT" = "bundle" ]; then
    binary="$BUNDLE_DST"
    # Only now, with the new service running: drop the moved-aside bundle and the
    # legacy bare file.
    case "$APPLY_ASIDE" in
      "$HELPER_DIR"/.QTakeSync\ Service.app.old-*) rm -rf "$APPLY_ASIDE" 2>/dev/null || true ;;
    esac
    APPLY_ASIDE=""
    if [ -e "$BIN_DST" ] || [ -L "$BIN_DST" ]; then
      rm -f "$BIN_DST" || echo "install.sh: warning: could not remove the legacy daemon file $BIN_DST" >&2
    fi
  fi

  echo "QTakeSync daemon installed."
  echo "  layout:  $LAYOUT"
  echo "  binary:  $binary"
  echo "  plist:   $PLIST_DST"
  echo "  config:  $CONF_FILE"
  echo "  state:   $STATE_DIR (kept as is)"
  echo "  right:   $RIGHT (admin, timeout 600 s)"
  echo "  pinned app CDHash: $hash"
  if [ "$LAYOUT" = "bundle" ]; then echo "  service certificate: $(daemon_cert_hex)"; fi
  echo "  version: $NEW_VER (build $NEW_BUILD)"
}

# apply_daemon runs in a subshell, where the main EXIT trap does not fire and
# TMP_FILES additions are lost; this runs as the subshell's own EXIT trap.
apply_cleanup() {
  local f
  # The install lock is NOT released here: the parent still runs the restore and
  # writes the result; only the main cleanup releases it.
  for f in ${TMP_FILES[@]+"${TMP_FILES[@]}"}; do
    [ -n "$f" ] && rm -f "$f" 2>/dev/null || true
  done
  # Half-copied service bundle: remove it (exact staging path only).
  case "$APPLY_NEW" in
    "$HELPER_DIR"/.QTakeSync\ Service.app.new-*) rm -rf "$APPLY_NEW" 2>/dev/null || true ;;
  esac
  # Finished: drop a moved-aside bundle that apply_rest could not remove.
  if [ "$APPLY_OK" -eq 1 ]; then
    case "$APPLY_ASIDE" in
      "$HELPER_DIR"/.QTakeSync\ Service.app.old-*) rm -rf "$APPLY_ASIDE" 2>/dev/null || true ;;
    esac
  fi
  # Install did not finish: put a moved-aside bundle back.
  if [ "$APPLY_OK" -ne 1 ]; then
    case "$APPLY_ASIDE" in
      "$HELPER_DIR"/.QTakeSync\ Service.app.old-*)
        if [ -d "$APPLY_ASIDE/$BUNDLE_NAME" ]; then
          [ ! -d "$BUNDLE_DST" ] || [ -L "$BUNDLE_DST" ] || rm -rf "$BUNDLE_DST" 2>/dev/null || true
          mv "$APPLY_ASIDE/$BUNDLE_NAME" "$BUNDLE_DST" 2>/dev/null && rmdir "$APPLY_ASIDE" 2>/dev/null || true
        else
          rmdir "$APPLY_ASIDE" 2>/dev/null || true
        fi ;;
    esac
  fi
}

# Removes a setup token file (stale tokens must not survive update/uninstall).
remove_setup_token() {
  local f="${1:-$SETUP_TOKEN_FILE}"
  if [ -e "$f" ] || [ -L "$f" ]; then rm -f "$f"; fi
  return 0
}

# Generates a token into SETUP_TOKEN and writes the hash file atomically
# (root:wheel 0600), overwriting any previous one. $1 = state dir (default
# STATE_DIR). The token is never passed as a command argument. Returns non-zero
# (no die, no token material on any output) on any failure; the caller decides.
write_setup_token() {
  local dir="${1:-$STATE_DIR}" dst tmp hex sum now
  SETUP_TOKEN=""
  [ -d "$dir" ] && [ ! -L "$dir" ] || return 1
  dst="$dir/setup-token.json"
  hex="$(head -c 32 /dev/urandom | xxd -p -c 64)" || return 1
  [[ $hex =~ ^[0-9a-f]{64}$ ]] || return 1
  sum="$(printf '%s' "$hex" | shasum -a 256 | cut -d' ' -f1)" || return 1
  [[ $sum =~ ^[0-9a-f]{64}$ ]] || return 1
  now="$(date +%s)" || return 1
  tmp="$(mktemp "$dir/.setup-token.XXXXXX")" || return 1
  TMP_FILES+=("$tmp")
  chmod 0600 "$tmp" || return 1
  printf '{"version":1,"sha256":"%s","issuedAt":%s,"idleSeconds":600,"maxSeconds":1800,"exportUsed":false}\n' \
    "$sum" "$now" > "$tmp" || return 1
  if [ "$(id -u)" -eq 0 ]; then chown root:wheel "$tmp" || return 1; fi
  mv -f "$tmp" "$dst" || return 1
  SETUP_TOKEN="$hex"
  hex=""
  return 0
}

# Prints the token once, as the last stdout line, then forgets it.
print_setup_token() {
  [ -n "$SETUP_TOKEN" ] || return 0
  printf 'QTAKESYNC-SETUP-TOKEN %s\n' "$SETUP_TOKEN"
  SETUP_TOKEN=""
  unset SETUP_TOKEN
}

cmd_install() {
  local app="" want_token=1 a
  for a in "$@"; do
    case "$a" in
      --no-token) want_token=0 ;;
      -*) die "usage: install.sh install [--no-token] <app bundle>" ;;
      *) [ -z "$app" ] || die "usage: install.sh install [--no-token] <app bundle>"; app="$a" ;;
    esac
  done
  [ -n "$app" ] || die "usage: install.sh install [--no-token] <app bundle>"
  stage_and_verify "$app"
  check_downgrade
  local rc=0
  set +e
  ( set -e; trap apply_cleanup EXIT; apply_daemon )
  rc=$?
  set -e
  [ "$rc" -eq 0 ] || exit "$rc"
  # Setup token: only for a first run (no secret yet) and unless --no-token.
  # A stale token file never survives a skipped issue. A token failure does not
  # fail the install: warning on stderr (no token material), no token line.
  if [ "$want_token" -eq 1 ] && [ ! -e "$SECRET_FILE" ] && [ ! -L "$SECRET_FILE" ]; then
    if write_setup_token "$STATE_DIR"; then
      print_setup_token
    else
      echo "install.sh: warning: could not create the setup token; the service is installed, continue with the administrator password" >&2
    fi
  else
    remove_setup_token || true
  fi
  return 0
}

# Copies the current daemon (legacy file and/or service bundle), plist and
# config.json into $SNAP. Whatever exists is saved; restore puts back the same.
snapshot_daemon() {
  SNAP="$(mktemp -d "$CONF_DIR/.snap.XXXXXX")"
  chmod 0700 "$SNAP"
  local f
  for f in "$BIN_DST:bin" "$PLIST_DST:plist" "$CONF_FILE:config"; do
    if [ -f "${f%:*}" ] && [ ! -L "${f%:*}" ]; then cp -p "${f%:*}" "$SNAP/${f##*:}"; fi
  done
  if [ -d "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ]; then
    ditto --noqtn --noacl "$BUNDLE_DST" "$SNAP/bundle"
  fi
}

# Puts the snapshot back and bootstraps the old daemon. Returns non-zero if it
# could not. The state of the daemon files is made equal to the snapshot: a
# bundle or legacy file that did not exist then is removed.
restore_daemon() {
  [ -n "$SNAP" ] && [ -d "$SNAP" ] || return 1
  [ -f "$SNAP/plist" ] || return 1
  [ -f "$SNAP/bin" ] || [ -d "$SNAP/bundle" ] || return 1
  launchctl bootout "system/$LABEL" 2>/dev/null || true
  wait_unloaded
  if [ -d "$SNAP/bundle" ]; then
    [ ! -L "$BUNDLE_DST" ] || return 1
    [ ! -e "$BUNDLE_DST" ] || rm -rf "$BUNDLE_DST" || return 1
    ditto --noqtn --noacl "$SNAP/bundle" "$BUNDLE_DST" || return 1
    ( strip_quarantine "$BUNDLE_DST" ) || return 1
    find "$BUNDLE_DST" ! -type l -exec chmod -N {} + || return 1
    chown -R root:wheel "$BUNDLE_DST" || return 1
    ( normalize_modes "$BUNDLE_DST"; check_world_readable "$BUNDLE_DST" ) || return 1
  elif [ -e "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ]; then
    rm -rf "$BUNDLE_DST" || return 1
  fi
  if [ -f "$SNAP/bin" ]; then
    install -m 0755 -o root -g wheel "$SNAP/bin" "$BIN_DST" || return 1
  elif [ -e "$BIN_DST" ] || [ -L "$BIN_DST" ]; then
    rm -f "$BIN_DST" || return 1
  fi
  install -m 0644 -o root -g wheel "$SNAP/plist" "$PLIST_DST" || return 1
  if [ -f "$SNAP/config" ]; then
    install -m 0644 -o root -g wheel "$SNAP/config" "$CONF_FILE" || return 1
  fi
  launchctl enable "system/$LABEL" 2>/dev/null || true
  launchctl bootstrap system "$PLIST_DST" || return 1
}

# The code object whose cdhash identifies the daemon in an app copy $1: the
# service bundle or the bare file, as detect_layout chose for the staged copy.
staged_daemon_object() {
  if [ "$LAYOUT" = "bundle" ]; then printf '%s' "$1/$APP_BUNDLE_REL"; else printf '%s' "$1/$APP_LEGACY_REL"; fi
}

APP_DST="/Applications/QTakeSync.app"

# Removes a leftover: a symlink only as the link, a directory recursively.
rm_leftover() {
  if [ -L "$1" ]; then rm -f "$1" 2>/dev/null || true
  elif [ -d "$1" ]; then rm -rf "$1" 2>/dev/null || true
  fi
  return 0
}

# Leftovers of runs killed hard (SIGKILL, power loss): exact name patterns at the
# constant parents only. Never touches $STAGE or $SNAP of the running installer, the
# installed app, or an old app copy (.QTakeSync.app.old-*/QTakeSync.app).
sweep_tmp_leftovers() {
  local d
  for d in /Applications/.QTakeSync.app.new-*; do
    { [ -e "$d" ] || [ -L "$d" ]; } || continue
    rm_leftover "$d"
  done
  for d in /Applications/.QTakeSync.app.old-*; do
    { [ -e "$d" ] || [ -L "$d" ]; } || continue
    if [ -e "$d/new-failed" ] || [ -L "$d/new-failed" ]; then rm_leftover "$d/new-failed"; fi
    rmdir "$d" 2>/dev/null || true
  done
  for d in "$CONF_DIR"/.stage.* "$CONF_DIR"/.snap.*; do
    { [ -e "$d" ] || [ -L "$d" ]; } || continue
    [ "$d" != "$STAGE" ] && [ "$d" != "$SNAP" ] || continue
    rm_leftover "$d"
  done
  return 0
}

# ADR-0011. Prints "<user> <uid> <home>" of the console user (ordinary account, uid >= 500),
# or nothing (login window, root, system account, unreadable home). Never fails.
console_user_info() {
  local u uid home
  u="$(stat -f %Su /dev/console 2>/dev/null)" || return 0
  case "$u" in ""|root|loginwindow|_*) return 0 ;; esac
  [[ $u =~ ^[A-Za-z0-9._-]+$ ]] || return 0
  uid="$(id -u "$u" 2>/dev/null)" || return 0
  [[ $uid =~ ^[0-9]+$ ]] && [ "$uid" -ge 500 ] || return 0
  home="$(dscl . -read "/Users/$u" NFSHomeDirectory 2>/dev/null | sed -n 's/^NFSHomeDirectory:[[:space:]]*//p' | head -n 1)" || home=""
  case "$home" in /*) ;; *) return 0 ;; esac
  printf '%s %s %s\n' "$u" "$uid" "$home"
}

# Restarts the console user's uploader agent when it is loaded, so it runs the new build.
# Every failure is ignored: the update has already succeeded.
kickstart_uploader() {
  local info uid
  info="$(console_user_info)" || info=""
  [ -n "$info" ] || return 0
  uid="$(printf '%s' "$info" | cut -d ' ' -f 2)"
  if launchctl print "gui/$uid/$UPLOADER_LABEL" >/dev/null 2>&1; then
    launchctl kickstart -k "gui/$uid/$UPLOADER_LABEL" >/dev/null 2>&1 || true
  fi
  return 0
}

# Uninstall: boots the console user's uploader agent out and removes its plist (the
# exact path; on a symlink only the link). Failures are ignored.
remove_uploader_agent() {
  local info uid home plist
  info="$(console_user_info)" || info=""
  [ -n "$info" ] || return 0
  uid="$(printf '%s' "$info" | cut -d ' ' -f 2)"
  home="$(printf '%s' "$info" | cut -d ' ' -f 3-)"
  launchctl bootout "gui/$uid/$UPLOADER_LABEL" >/dev/null 2>&1 || true
  # Refuse when any component from the home down is a symlink (the home is user-writable:
  # a swapped Library or LaunchAgents link would let root delete elsewhere).
  local c
  for c in "$home" "$home/Library" "$home/Library/LaunchAgents"; do
    if [ -L "$c" ]; then
      echo "install.sh: $c is a symlink; the uploader agent plist was not removed" >&2
      return 0
    fi
    [ -d "$c" ] || return 0
  done
  plist="$home/Library/LaunchAgents/$UPLOADER_LABEL.plist"
  if [ -L "$plist" ] || [ -f "$plist" ]; then rm -f "$plist" || true; fi
  return 0
}

# Replaces /Applications/QTakeSync.app from the staged copy, then installs the
# daemon from the same staged copy.
cmd_update() {
  local uargs=() ua
  for ua in "$@"; do
    if [ "$ua" = "--rotate-key" ]; then ROTATE_KEY=1; else uargs+=("$ua"); fi
  done
  set -- ${uargs[@]+"${uargs[@]}"}
  [ $# -eq 3 ] || die "usage: install.sh update [--rotate-key] <new QTakeSync.app> <app cdhash> <daemon cdhash>"
  local exp_app="$2" exp_daemon="$3"
  UPDATE_RUN=1
  is_hash40 "$exp_app" || die "app cdhash argument must be 40 lowercase hex characters"
  is_hash40 "$exp_daemon" || die "daemon cdhash argument must be 40 lowercase hex characters"
  stage_and_verify "$1"
  [ "$HASH" = "$exp_app" ] || die "update does not match the verified build (app CDHash)"
  same_cdhash "$(cdhash_of "$(staged_daemon_object "$SAPP")")" "$exp_daemon" || die "update does not match the verified build (daemon CDHash)"
  if [ "$STAGED_MODE" -eq 1 ]; then
    [ "$((10#$NEW_BUILD))" -eq "$((10#$STAGED_BUILD))" ] \
      || die "staged build ($NEW_BUILD) differs from its directory name ($STAGED_BUILD)"
  fi
  check_downgrade
  if [ "$STAGED_MODE" -eq 0 ]; then check_pubkey_change; else require_same_pubkey; fi
  [ "$STAGED_MODE" -eq 0 ] || require_strictly_newer
  remove_setup_token

  local old_daemon_hash new_daemon_hash old_app_hash="none" owner="root:wheel" old_layout="none"
  if [ -d "$BUNDLE_DST" ] && [ ! -L "$BUNDLE_DST" ]; then
    old_layout="bundle"; old_daemon_hash="$(cdhash_of "$BUNDLE_DST")"
  elif [ -f "$BIN_DST" ]; then
    old_layout="legacy"; old_daemon_hash="$(cdhash_of "$BIN_DST")"
  else
    old_daemon_hash="none"
  fi
  if [ "$STAGED_MODE" -eq 1 ] && [ "$old_layout" = "bundle" ] && [ "$LAYOUT" = "legacy" ]; then
    die "update-staged: the installed service is a bundle, the staged app carries the legacy bare daemon (layout downgrade refused)"
  fi
  new_daemon_hash="$(cdhash_of "$(staged_daemon_object "$SAPP")")"
  if [ -f "$CONF_FILE" ]; then
    old_app_hash="$(sed -n 's/.*"appCDHashes": *\["\([0-9a-fA-F]*\)".*/\1/p' "$CONF_FILE" | head -n 1)" || true
    [ -n "$old_app_hash" ] || old_app_hash="unknown"
  fi

  [ ! -L "$APP_DST" ] || die "$APP_DST is a symlink"
  # Leftover of a run killed hard (SIGKILL, power loss) after the move-aside: put the
  # old app back when nothing is installed, then drop empty leftovers.
  local lo
  for lo in /Applications/.QTakeSync.app.old-*; do
    [ -d "$lo" ] && [ ! -L "$lo" ] || continue
    if [ ! -e "$APP_DST" ] && [ -d "$lo/QTakeSync.app" ] && [ ! -L "$lo/QTakeSync.app" ]; then
      move_dir_to "$lo/QTakeSync.app" "$APP_DST" || continue
    fi
    rmdir "$lo" 2>/dev/null || true
  done
  sweep_tmp_leftovers
  if [ -e "$APP_DST" ]; then
    [ -d "$APP_DST" ] || die "$APP_DST is not a directory"
    owner="$(stat -f '%Su:%Sg' "$APP_DST")"
  fi
  # update-staged runs as root with nobody to ask: the app belongs to the console user.
  [ -z "$OWNER_OVERRIDE" ] || owner="$OWNER_OVERRIDE"

  local newdir olddir
  newdir="$(mktemp -d "/Applications/.QTakeSync.app.new-XXXXXX")"
  NEW_APP_TMP="$newdir"
  ditto --noqtn --noacl "$SAPP" "$newdir"
  # The user already approved QTakeSync; a quarantined new app would ask Gatekeeper again.
  strip_quarantine "$newdir"
  chown -R "$owner" "$newdir"
  normalize_modes "$newdir"
  codesign --verify --strict "$newdir" || die "copied app signature is invalid"
  same_cdhash "$(cdhash_of "$(staged_daemon_object "$newdir")")" "$new_daemon_hash" \
    || die "daemon changed while copying (or cdhash unreadable)"

  # Snapshot of the current daemon BEFORE anything is swapped: a failure of the
  # snapshot itself then leaves everything as it was (set -e, cleanup removes SNAP).
  snapshot_daemon
  check_interrupted
  if [ -e "$APP_DST" ]; then
    olddir="$(mktemp -d "/Applications/.QTakeSync.app.old-XXXXXX")"
    OLD_APP_TMP="$olddir"
    mv "$APP_DST" "$olddir/QTakeSync.app" || die "cannot move the current app aside"
    [ ! -e "$APP_DST" ] && [ ! -L "$APP_DST" ] || die "$APP_DST reappeared while updating"
    if ! move_dir_to "$newdir" "$APP_DST"; then
      move_dir_to "$olddir/QTakeSync.app" "$APP_DST" || echo "install.sh: RESTORE FAILED, old app is in $olddir" >&2
      die "cannot put the new app in place; old app restored"
    fi
    NEW_APP_TMP=""
  else
    [ ! -e "$APP_DST" ] && [ ! -L "$APP_DST" ] || die "$APP_DST appeared while updating"
    move_dir_to "$newdir" "$APP_DST" || die "cannot put the new app in place"
    NEW_APP_TMP=""
  fi

  # Daemon install failure after the swap: restore the old app bundle.
  # set -e is ignored inside an `if` condition, so run the subshell on its own.
  local rc=0
  set +e
  # Staged: the apply subshell ignores TERM/HUP/INT (a group-wide signal must not
  # kill it half way); the parent only records the signal in INTERRUPTED.
  ( set -e; [ "$STAGED_MODE" -eq 0 ] || trap '' TERM HUP INT; trap apply_cleanup EXIT; apply_daemon )
  rc=$?
  set -e
  if [ "$rc" -ne 0 ]; then
    if restore_daemon; then
      echo "install.sh: daemon install failed, old daemon restored and started" >&2
    else
      echo "install.sh: daemon install failed and the old daemon could not be restored. Reinstall the service from the QTakeSync Service pane." >&2
    fi
    if [ -n "${OLD_APP_TMP:-}" ] && [ -d "$OLD_APP_TMP/QTakeSync.app" ]; then
      # Only when the failed new app is really out of the way: otherwise the old app
      # would land INSIDE it and "restored" would be a lie.
      if move_dir_to "$APP_DST" "$OLD_APP_TMP/new-failed"; then
        if move_dir_to "$OLD_APP_TMP/QTakeSync.app" "$APP_DST"; then
          echo "install.sh: daemon install failed, old app restored" >&2
        else
          echo "install.sh: RESTORE FAILED, old app is in $OLD_APP_TMP" >&2
        fi
      else
        echo "install.sh: could not move the failed new app aside; the old app stays in $OLD_APP_TMP and the new app stays in $APP_DST" >&2
      fi
      OLD_APP_TMP_KEEP=1
    fi
    if [ "$INTERRUPTED" -eq 1 ]; then die "interrupted by a signal during the daemon install; the old app and daemon were restored (see install.log)"; fi
    die "daemon install failed during update"
  fi
  case "$OLD_APP_TMP" in
    /Applications/.QTakeSync.app.old-*) rm -rf "$OLD_APP_TMP" ;;
  esac
  OLD_APP_TMP=""

  RESULT_MSG="updated to $NEW_VER (build $NEW_BUILD)"
  echo "QTakeSync updated."
  echo "  app:     $APP_DST (owner $owner)"
  echo "  app CDHash:    $old_app_hash -> $HASH"
  [ -z "$STAGED_PUBKEY" ] || echo "  update public key: $STAGED_PUBKEY"
  echo "  daemon CDHash: $old_daemon_hash -> $new_daemon_hash"
  echo "  daemon layout: $old_layout -> $LAYOUT"
  if [ "$LAYOUT" = "bundle" ] && [ "$old_layout" = "bundle" ]; then
    # Same signing requirement on both sides (the installer refuses any other):
    # Full Disk Access survives a changed cdhash.
    echo "  daemon changed: no (same signing requirement, Full Disk Access is kept)"
  elif [ "$LAYOUT" = "bundle" ] && [ "$old_layout" != "none" ]; then
    echo "  daemon changed: YES (new service layout: grant Full Disk Access to QTakeSync Service once, remove the old local.qtakesync.daemon entry)"
  elif [ "$old_daemon_hash" = "$new_daemon_hash" ]; then
    echo "  daemon changed: no"
  else
    echo "  daemon changed: YES (Full Disk Access for the daemon must be granted again)"
  fi
  kickstart_uploader
}

# Checks one path component: a real directory (no symlink), root:wheel, no group or
# other write bit, no ACL.
check_trusted_dir() {
  local p="$1" mode
  [ -d "$p" ] && [ ! -L "$p" ] || die "update-staged: $p is not a plain directory"
  [ "$(stat -f '%Su:%Sg' "$p")" = "$ROOT_USER:$ROOT_GROUP" ] || die "update-staged: $p is not owned by $ROOT_USER:$ROOT_GROUP"
  mode="$(stat -f '%Lp' "$p")"
  [[ $mode =~ ^[0-7]{3,4}$ ]] || die "update-staged: cannot read the mode of $p"
  [ "$(( 8#$mode & 8#022 ))" -eq 0 ] || die "update-staged: $p is writable by group or others"
  [ -z "$(find "$p" -maxdepth 0 -acl -print)" ] || die "update-staged: $p carries an ACL"
  return 0
}

# Sets OWNER_OVERRIDE ("user:group"): the installed app's owner and group when it is
# owned by an ordinary user (uid >= 500); otherwise the console user
# (stat -f %Su /dev/console, uid >= 500; login window or root: refused).
resolve_console_owner() {
  local u g cur="" curuid
  if [ -e "$APP_DST" ] && [ ! -L "$APP_DST" ]; then cur="$(stat -f %Su "$APP_DST" 2>/dev/null)" || cur=""; fi
  # An installed app owned by an ordinary user keeps its owner and group.
  if [ -n "$cur" ]; then
    curuid="$(stat -f %u "$APP_DST" 2>/dev/null)" || curuid=0
    if [[ $curuid =~ ^[0-9]+$ ]] && [ "$curuid" -ge 500 ]; then
      OWNER_OVERRIDE="$cur:$(stat -f %Sg "$APP_DST")"
      return 0
    fi
  fi
  # No installed app (or root-owned): the console user.
  u="$(stat -f %Su /dev/console 2>/dev/null)" || u=""
  case "$u" in ""|root|loginwindow|_*) die "update-staged: no console user to own the app" ;; esac
  [[ $u =~ ^[A-Za-z0-9._-]+$ ]] || die "update-staged: unusable console user name"
  id -u "$u" >/dev/null 2>&1 || die "update-staged: console user $u does not exist"
  [ "$(id -u "$u")" -ge 500 ] || die "update-staged: console user $u is a system account"
  g="$(id -gn "$u")"
  OWNER_OVERRIDE="$u:$g"
}

cmd_update_staged() {
  local sa
  for sa in "$@"; do
    [ "$sa" != "--rotate-key" ] || die "update-staged: --rotate-key is not accepted here; key rotation is a manual root command (install.sh update --rotate-key)"
  done
  [ $# -eq 3 ] || die "usage: install.sh update-staged <app in $UPDATES_DIR/<build>/> <app cdhash> <daemon cdhash>"
  local app="$1" rest b
  # Shape first (no filesystem access): exactly $UPDATES_DIR/<build>/QTakeSync.app.
  case "$app" in "$UPDATES_DIR"/*) ;; *) die "update-staged: the app must be inside $UPDATES_DIR" ;; esac
  rest="${app#"$UPDATES_DIR"/}"
  b="${rest%%/*}"
  [ "$rest" = "$b/QTakeSync.app" ] || die "update-staged: the app path must be $UPDATES_DIR/<build>/QTakeSync.app"
  is_build "$b" || die "update-staged: the directory name is not a build number"
  STAGED_BUILD="$b"
  # Every component from CONF_DIR down. Result file only after the updates dir is trusted.
  check_trusted_dir "$CONF_DIR"
  check_trusted_dir "$UPDATES_DIR"
  STAGED_MODE=1
  RESULT_ENABLED=1
  # A signal only sets a flag: the apply and its rollback run to the end; the flag is
  # checked before the app is replaced (check_interrupted) and after a failed apply.
  trap 'INTERRUPTED=1' TERM HUP INT
  check_trusted_dir "$UPDATES_DIR/$b"
  check_trusted_dir "$app"
  [ "$(cd -P "$app" && pwd -P)" = "$app" ] || die "update-staged: the app path is not a physical path (symlink above?)"
  [ -z "$(find "$app" \( ! -user "$ROOT_USER" -o -perm -g+w -o -perm -o+w \) -print -quit)" ] \
    || die "update-staged: the staged app has files not owned by $ROOT_USER or writable by group/others"
  resolve_console_owner
  acquire_lock
  cmd_update "$@"
}

cmd_uninstall() {
  remove_setup_token
  launchctl bootout "system/$UPDATER_LABEL" 2>/dev/null || true
  launchctl bootout "system/$LABEL" 2>/dev/null || true
  wait_unloaded
  remove_uploader_agent
  if [ -L "$UPDATES_DIR" ]; then
    rm -f "$UPDATES_DIR"                      # the link only, never its target
  elif [ -d "$UPDATES_DIR" ]; then
    rm -rf "$UPDATES_DIR"                     # exact constant path (stage dirs, last-result.json)
  fi
  unmount_leftovers
  sweep_stale_helper_dirs
  sweep_tmp_leftovers
  # ADR-0011: cloud tokens and upload manifests (exact paths; on a symlink only the link).
  local ud
  for ud in "$STATE_DIR/cloud-accounts" "$STATE_DIR/upload"; do
    if [ -L "$ud" ]; then
      rm -f "$ud"
    elif [ -d "$ud" ]; then
      rm -rf "$ud"
    elif [ -e "$ud" ]; then
      rm -f "$ud"
    fi
  done
  [ ! -e "$BIN_DST" ] && [ ! -L "$BIN_DST" ] || rm -f "$BIN_DST"
  if [ -L "$BUNDLE_DST" ]; then
    rm -f "$BUNDLE_DST"
  elif [ -e "$BUNDLE_DST" ]; then
    rm -rf "$BUNDLE_DST"   # exact constant path under /Library/PrivilegedHelperTools
  fi
  [ ! -e "$PLIST_DST" ] && [ ! -L "$PLIST_DST" ] || rm -f "$PLIST_DST"
  [ ! -e "$CONF_FILE" ] && [ ! -L "$CONF_FILE" ] || rm -f "$CONF_FILE"
  [ ! -e "$PUBLIC_RESULT_FILE" ] && [ ! -L "$PUBLIC_RESULT_FILE" ] || rm -f "$PUBLIC_RESULT_FILE"
  security authorizationdb remove "$RIGHT" >/dev/null 2>&1 || true
  echo "QTakeSync daemon uninstalled (binary or service bundle, plist, config.json, authorization right, state/cloud-accounts, state/upload, the console user's uploader agent plist)."
  echo "Kept on purpose: $CONF_DIR/state/ (including state/merge/) and $CONF_DIR/settings.json (its upload plan is inert without accounts)."
  echo "Cloud access granted to QTakeSync stays active at Yandex unless you used Disconnect before uninstalling; revoke it at id.yandex.ru → Data access."
}

case "${1:-}" in
  install)   shift; acquire_lock; cmd_install "$@" ;;
  update)    shift; acquire_lock; cmd_update "$@" ;;
  update-staged) shift; cmd_update_staged "$@" ;;
  uninstall) acquire_lock; cmd_uninstall ;;
  *) die "usage: install.sh install [--no-token] <app bundle> | update [--rotate-key] <new app bundle> <app cdhash> <daemon cdhash> | update-staged <staged app> <app cdhash> <daemon cdhash> | uninstall" ;;
esac
